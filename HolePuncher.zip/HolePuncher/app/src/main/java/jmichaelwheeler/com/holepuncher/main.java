package jmichaelwheeler.com.holepuncher;

import android.content.Intent;
import android.graphics.Point;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class main extends AppCompatActivity {

    private TextView score;
    private TextView start;
    private ImageView fist;
    private ImageView hole;
    private ImageView ball;
    private ImageView brick;
    private ImageView brick2;
    private ImageView brick3;
    private ImageView brick4;
    private ImageView brick5;
    private ImageView brick6;
    private ImageView brick7;
    private ImageView brick8;
    private ImageView brick9;
    private ImageView brick10;
    private ImageView brick11;
    private ImageView brick12;
    private ImageView brick13;
    private ImageView brick14;
    private ImageView brick15;
    private ImageView brick16;
    private ImageView brick17;
    private ImageView brick18;
    private ImageView brick19;
    private ImageView brick20;
    private ImageView brick21;

    //Size
    private int frameWidth;
    private int fistSize;
    private int screenWidth;
    private int screenHeight;
    private int holeSize;

    //Position
    private int fistX;
    private float fistY;
    private int ballX;
    private float ballY;
    private float holeX;
    private float holeY;
    private int XVelocity;

    //Score
    private int points = 0;

    //--------------------------------------
    //brick Positions
    private int brickX;
    private int brickY;
    private int brick2X;
    private int brick2Y;
    private int brick3X;
    private int brick3Y;
    private int brick4X;
    private int brick4Y;
    private int brick5X;
    private int brick5Y;
    private int brick6X;
    private int brick6Y;
    private int brick7X;
    private int brick7Y;
    private int brick8X;
    private int brick8Y;
    private int brick9X;
    private int brick9Y;
    private int brick10X;
    private int brick10Y;
    private int brick11X;
    private int brick11Y;
    private int brick12X;
    private int brick12Y;
    private int brick13X;
    private int brick13Y;
    private int brick14X;
    private int brick14Y;
    private int brick15X;
    private int brick15Y;
    private int brick16X;
    private int brick16Y;
    private int brick17X;
    private int brick17Y;
    private int brick18X;
    private int brick18Y;
    private int brick19X;
    private int brick19Y;
    private int brick20X;
    private int brick20Y;
    private int brick21X;
    private int brick21Y;

    //---------------------------------------
    //Initialize Class
    private Handler handler = new Handler();
    private Timer timer = new Timer();

    //Status Check
    private boolean action_flg = false;
    private boolean start_flg = false;
    private boolean hitflag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        score = (TextView) findViewById(R.id.score);
        start = (TextView) findViewById(R.id.start);
        fist = (ImageView) findViewById(R.id.fist);
        hole = (ImageView) findViewById(R.id.hole);
        ball = (ImageView) findViewById(R.id.ball);
        brick = (ImageView) findViewById(R.id.brick);
        brick2 = (ImageView) findViewById(R.id.brick2);
        brick3 = (ImageView) findViewById(R.id.brick3);
        brick4 = (ImageView) findViewById(R.id.brick4);
        brick5 = (ImageView) findViewById(R.id.brick5);
        brick6 = (ImageView) findViewById(R.id.brick6);
        brick7 = (ImageView) findViewById(R.id.brick7);
        brick8 = (ImageView) findViewById(R.id.brick8);
        brick9 = (ImageView) findViewById(R.id.brick9);
        brick10 = (ImageView) findViewById(R.id.brick10);
        brick11 = (ImageView) findViewById(R.id.brick11);
        brick12 = (ImageView) findViewById(R.id.brick12);
        brick13 = (ImageView) findViewById(R.id.brick13);
        brick14 = (ImageView) findViewById(R.id.brick14);
        brick15 = (ImageView) findViewById(R.id.brick15);
        brick16 = (ImageView) findViewById(R.id.brick16);
        brick17 = (ImageView) findViewById(R.id.brick17);
        brick18 = (ImageView) findViewById(R.id.brick18);
        brick19 = (ImageView) findViewById(R.id.brick19);
        brick20 = (ImageView) findViewById(R.id.brick20);
        brick21 = (ImageView) findViewById(R.id.brick21);

        score.setText("Score : 0");

        //Get Screen Size.
        WindowManager wm = getWindowManager();
        Display disp = wm.getDefaultDisplay();
        Point size = new Point();
        disp.getSize(size);

        screenWidth = size.x;
        screenHeight = size.y;

        //center the ball
        ballY = 720;
        ballX = 510;
        ball.setY(ballY);
        ball.setX(ballX);

        //fist Y established
        fist.setY(1550);
        fistY = fist.getY();

        //hole placement
        holeSize = hole.getWidth();
        Random r = new Random();
        int holeBorder = holeSize * 2;
        int h1 = r.nextInt(screenWidth-200)+ 100;
        hole.setX(h1);
        holeX = hole.getX();
        holeY = hole.getY();

        //---------------------------------------------------------
        //X: 0,50,100,150,200,250,300  315,265,215,165,115,65,15  0,50,100,150,200,250,300 Y:50,64,78

        //brick
        brickX = 0;
        brickY = 100;
        brick.setX(brickX);
        brick.setY(brickY);

        //brick2
        brick2X = 150;
        brick2Y = 100;
        brick2.setX(brick2X);
        brick2.setY(brick2Y);

        //brick3
        brick3X = 300;
        brick3Y = 100;
        brick3.setX(brick3X);
        brick3.setY(brick3Y);

        //brick4
        brick4X = 450;
        brick4Y = 100;
        brick4.setX(brick4X);
        brick4.setY(brick4Y);

        //brick5
        brick5X = 600;
        brick5Y = 100;
        brick5.setX(brick5X);
        brick5.setY(brick5Y);

        //brick6
        brick6X = 750;
        brick6Y = 100;
        brick6.setX(brick6X);
        brick6.setY(brick6Y);

        //brick7
        brick7X = 900;
        brick7Y = 100;
        brick7.setX(brick7X);
        brick7.setY(brick7Y);

        //brick8
        brick8X = 925;
        brick8Y = 150;
        brick8.setX(brick8X);
        brick8.setY(brick8Y);

        //brick9
        brick9X = 775;
        brick9Y = 150;
        brick9.setX(brick9X);
        brick9.setY(brick9Y);

        //brick10
        brick10X = 625;
        brick10Y = 150;
        brick10.setX(brick10X);
        brick10.setY(brick10Y);

        //brick11
        brick11X = 475;
        brick11Y = 150;
        brick11.setX(brick11X);
        brick11.setY(brick11Y);

        //brick12
        brick12X = 325;
        brick12Y = 150;
        brick12.setX(brick12X);
        brick12.setY(brick12Y);

        //brick13
        brick13X = 175;
        brick13Y = 150;
        brick13.setX(brick13X);
        brick13.setY(brick13Y);

        //brick14
        brick14X = 25;
        brick14Y = 150;
        brick14.setX(brick14X);
        brick14.setY(brick14Y);

        //brick15
        brick15X = 0;
        brick15Y = 200;
        brick15.setX(brick15X);
        brick15.setY(brick15Y);

        //brick16
        brick16X = 150;
        brick16Y = 200;
        brick16.setX(brick16X);
        brick16.setY(brick16Y);

        //brick17
        brick17X = 300;
        brick17Y = 200;
        brick17.setX(brick17X);
        brick17.setY(brick17Y);

        //brick18
        brick18X = 450;
        brick18Y = 200;
        brick18.setX(brick18X);
        brick18.setY(brick18Y);

        //brick19
        brick19X = 600;
        brick19Y = 200;
        brick19.setX(brick19X);
        brick19.setY(brick19Y);

        //brick20
        brick20X = 750;
        brick20Y = 200;
        brick20.setX(brick20X);
        brick20.setY(brick20Y);

        //brick21
        brick21X = 900;
        brick21Y = 200;
        brick21.setX(brick21X);
        brick21.setY(brick21Y);

//------------------------------------------------------------------------------
    }


    public void changePos(){

        //hitCheck
        if(fistX > ballX - 110 && fistX < ballX + 110 && fistY > ballY - 50 && fistY < ballY + 50) {
            hitflag = true;
            //ballY -= 200;

            //fistX >= ballX - 10 && fistX <= ballX + 10 &&
            //fistY <= ballY + 20 && fistY >= ballY - 20
        }
        Random r1 = new Random();
        int b1 = r1.nextInt(1+1+5)-5;
        if (hitflag == true) {
            ballY -= 10;
            ball.setY(ballY);
            ballX += b1;
            ball.setX(ballX);

        }
        //XVelocity check
        if (XVelocity == 1) {
            ballX += 10;
            ball.setX(ballX);
        } else if (XVelocity == 2) {
            ballX -= 10;
            ball.setX(ballX);
        }
        //top border
        if (ballY <= 0) {
            //Stop timer
            timer.cancel();
            timer = null;
            //Show Result.
            startActivity(new Intent(getApplicationContext(),missed.class));
        }
        //left border
        if (ballX <= 25) {
            XVelocity = 1;
        }
        //right border
        if (ballX >= screenWidth-50) {
            XVelocity = 2;
        }

        // botton border
        if (ballY >= screenHeight-50) {
            hitflag = true;

            //Stop timer
            timer.cancel();
            timer = null;

            //Show Result.

            startActivity(new Intent(getApplicationContext(),missed.class));

            //Intent intent = new Intent(getApplicationContext(), missed.class);
            //intent.putExtra("SCORE", points);
            //startActivity(intent);
        }

        //hole collision
        if (holeX > ballX - 150 && holeX < ballX + 150 && holeY > ballY - 150 && holeY < ballY + 150) {
            //Stop timer
            timer.cancel();
            timer = null;

            //Show Result.
            Intent intent = new Intent(getApplicationContext(), result.class);
            intent.putExtra("SCORE", points);
            startActivity(intent);
        }
        //-----------------------

        //brick collision

        if (brickX > ballX - 100 && brickX < ballX + 100 && brickY > ballY - 100 && brickY < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brickY = -100;
            brick.setY(brickY);
            points += 20;
        }

        //brick2 collision

        if (brick2X > ballX - 100 && brick2X < ballX + 100 && brick2Y > ballY - 100 && brick2Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick2Y = -100;
            brick2.setY(brick2Y);
            points += 20;
        }

        //brick3 collision

        if (brick3X > ballX - 100 && brick3X < ballX + 100 && brick3Y > ballY - 100 && brick3Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick3Y = -100;
            brick3.setY(brick3Y);
            points += 20;
        }

        //brick4 collision
        if (brick4X > ballX - 100 && brick4X < ballX + 100 && brick4Y > ballY - 100 && brick4Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick4Y = -100;
            brick4.setY(brick4Y);
            points += 20;
        }

        //brick5 collision

        if (brick5X > ballX - 100 && brick5X < ballX + 100 && brick5Y > ballY - 100 && brick5Y < ballY + 100) {
            hitflag = false;
            XVelocity = 2;
            brick5Y = -100;
            brick5.setY(brick5Y);
            points += 20;
        }

        //brick6 collision

        if (brick6X > ballX - 100 && brick6X < ballX + 100 && brick6Y > ballY - 100 && brick6Y < ballY + 100) {
            hitflag = false;
            XVelocity = 2;
            brick6Y = -100;
            brick6.setY(brick6Y);
            points += 20;
        }

        //brick7 collision

        if (brick7X > ballX - 100 && brick7X < ballX + 100 && brick7Y > ballY - 100 && brick7Y < ballY + 100) {
            hitflag = false;
            XVelocity = 2;
            brick7Y = -100;
            brick7.setY(brick7Y);
            points += 20;
        }

        //brick8 collision

        if (brick8X > ballX - 100 && brick8X < ballX + 100 && brick8Y > ballY - 100 && brick8Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick8Y = -100;
            brick8.setY(brick8Y);
            points += 20;
        }

        //brick9 collision

        if (brick9X > ballX - 100 && brick9X < ballX + 100 && brick9Y > ballY - 100 && brick9Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick9Y = -100;
            brick9.setY(brick9Y);
            points += 20;
        }

        //brick10 collision

        if (brick10X > ballX - 100 && brick10X < ballX + 100 && brick10Y > ballY - 100 && brick10Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick10Y = -100;
            brick10.setY(brick10Y);
            points += 20;
        }

        //brick11 collision
        if (brick11X > ballX - 100 && brick11X < ballX + 100 && brick11Y > ballY - 100 && brick11Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick11Y = -100;
            brick11.setY(brick11Y);
            points += 20;
        }

        //brick12 collision

        if (brick12X > ballX - 100 && brick12X < ballX + 100 && brick12Y > ballY - 100 && brick12Y < ballY + 100) {
            hitflag = false;
            XVelocity = 2;
            brick12Y = -100;
            brick12.setY(brick12Y);
            points += 20;
        }

        //brick13 collision

        if (brick13X > ballX - 100 && brick13X < ballX + 100 && brick13Y > ballY - 100 && brick13Y < ballY + 100) {
            hitflag = false;
            XVelocity = 2;
            brick13Y = -100;
            brick13.setY(brick13Y);
            points += 20;
        }

        //brick14 collision

        if (brick14X > ballX - 100 && brick14X < ballX + 100 && brick14Y > ballY - 100 && brick14Y < ballY + 100) {
            hitflag = false;
            XVelocity = 2;
            brick14Y = -100;
            brick14.setY(brick14Y);
            points += 20;
        }

        //brick15 collision

        if (brick15X > ballX - 100 && brick15X < ballX + 100 && brick15Y > ballY - 100 && brick15Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick15Y = -100;
            brick15.setY(brick15Y);
            points += 20;
        }

        //brick16 collision

        if (brick16X > ballX - 100 && brick16X < ballX + 100 && brick16Y > ballY - 100 && brick16Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick16Y = -100;
            brick16.setY(brick16Y);
            points += 20;
        }

        //brick17 collision

        if (brick17X > ballX - 100 && brick17X < ballX + 100 && brick17Y > ballY - 100 && brick17Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick17Y = -100;
            brick17.setY(brick17Y);
            points += 20;
        }

        //brick18 collision
        if (brick18X > ballX - 100 && brick18X < ballX + 100 && brick18Y > ballY - 100 && brick18Y < ballY + 100) {
            hitflag = false;
            XVelocity = 1;
            brick18Y = -100;
            brick18.setY(brick18Y);
            points += 20;
        }

        //brick19 collision

        if (brick19X > ballX - 100 && brick19X < ballX + 100 && brick19Y > ballY - 100 && brick19Y < ballY + 100) {
            hitflag = false;
            XVelocity = 2;
            brick19Y = -100;
            brick19.setY(brick19Y);
            points += 20;
        }

        //brick20 collision

        if (brick20X > ballX - 100 && brick20X < ballX + 100 && brick20Y > ballY - 100 && brick20Y < ballY + 100) {
            hitflag = false;
            XVelocity = 2;
            brick20Y = -100;
            brick20.setY(brick20Y);
            points += 20;
        }

        //brick21 collision

        if (brick21X > ballX - 100 && brick21X < ballX + 100 && brick21Y > ballY - 100 && brick21Y < ballY + 100) {
            hitflag = false;
            XVelocity = 2;
            brick21Y = -100;
            brick21.setY(brick21Y);
            points += 20;
        }

        //Ball
        if (ballY < screenHeight && hitflag == false) {
            ballY += 10;
            ball.setY(ballY);
        }


        //Move fist
        if(action_flg == true){
            //Touching
            fistX -= 20;

        }else {
            //Releasing
            fistX += 20;
        }

        //Check fist position.
        if (fistX < 0) fistX = 0;

        if (fistX > frameWidth - fistSize) fistX = frameWidth - fistSize;

        fist.setX(fistX);

        score.setText("Score : " + points);

    }

    public boolean onTouchEvent(MotionEvent me) {

        if(start_flg == false) {
            start_flg = true;

            //why get Frame Height and Fist Height here?
            //Because the UI has not been set on the screen in OnCreate()!!

            FrameLayout frame = (FrameLayout) findViewById(R.id.frame);
            frameWidth = frame.getWidth();

            fistX = (int)fist.getX();

            //fist is the same size for height and width (59 pixels)
            fistSize = fist.getHeight();


            start.setVisibility(View.GONE);

            timer.schedule(new TimerTask(){
                @Override
                public void run() {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            changePos();
                        }
                    });
                }
            },0, 20);

        }else {
            if(me.getAction() == MotionEvent.ACTION_DOWN){
                action_flg = true;

            } else if (me.getAction() == MotionEvent.ACTION_UP){
                action_flg = false;
            }
        }

        return true;
    }
}
